function getLearnerData(courseInfo, assignmentGroup, learnerSubmissions) {
    const results = [];
  
    try {
      if (assignmentGroup.course_id !== courseInfo.id) throw new Error("Course ID mismatch");
  
      const currentDate = new Date();
      const validAssignments = assignmentGroup.assignments.filter(assignment => {
        const dueDate = new Date(assignment.due_at);
        return typeof assignment.points_possible === 'number' && assignment.points_possible > 0 && dueDate <= currentDate;
      });
  
      const learners = {};
  
      for (let submission of learnerSubmissions) {
        const { learner_id, assignment_id, submission: { score, submitted_at } } = submission;
        const assignment = validAssignments.find(a => a.id === assignment_id);
        if (!assignment || typeof score !== 'number') continue;
  
        let adjustedScore = score;
        const submittedAt = new Date(submitted_at);
        if (submittedAt > new Date(assignment.due_at)) {
          adjustedScore = Math.max(score - 0.1 * assignment.points_possible, 0);
        }
  
        if (!learners[learner_id]) learners[learner_id] = { totalScore: 0, totalPossible: 0, scores: {} };
        learners[learner_id].totalScore += adjustedScore;
        learners[learner_id].totalPossible += assignment.points_possible;
        learners[learner_id].scores[assignment_id] = Number(((adjustedScore / assignment.points_possible) * 100).toFixed(2));
      }
  
      for (let learnerId in learners) {
        const learner = learners[learnerId];
        const avg = learner.totalPossible > 0 ? Number(((learner.totalScore / learner.totalPossible) * 100).toFixed(2)) : 0;
        results.push({ id: learnerId, avg: avg, ...learner.scores });
      }
  
    } catch (error) {
      console.error(error.message);
    }
  
    return results;
  }